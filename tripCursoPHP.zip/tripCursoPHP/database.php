<?php
	error_reporting(0);
	require_once('config.php');

	class DBM{
		private $MySQLi;
		public function conexion()
		{
			return self::conectar();
		}
		private function conectar(){

			try {
				$MySQLi = $this->mysqli = new MySQLi (DB_HOST,DB_USER,DB_PASS,DB_DATABASE);
			} catch (Exception $e) {
				$debugger = '<b>Error al conectar al Servidor !!!<br>Error: </b> '.$e;
				// echo $debugger;
				$error ='<br>
						<div class="centrar" style="font-size:25px;">
							<div class="label label-danger">
            					Error de Conexion, contacte con un Administrador !!!
        					</div>
        				</div>
        				<br>';
        		echo $error;
			}

			$MySQLi->set_charset('utf8');

			// DataBase connection info
			// var_dump($this->mysqli);

			$response = '';
			$response .= $this->mysqli->host_info . "<br>";
			$response .= 'Conectado al Servidor: <b>'.DB_HOST.'</b><br>';
			$response .= 'Base de Datos: <b>'.DB_DATABASE.'</b><br>';

			$response .= ('Conjunto de caracteres de la Base de Datos es: <b>'.$this->mysqli->character_set_name().'</b><br>');
			// echo $response;

		}

		// Metodo publico para desconectarnos
		public function desconectar(){
			$MySQLi = $this->mysqli;

			// Si hay una conexion, la cerramos
			if (isset($MySQLi)) {
                $cerrar = $MySQLi->close();
                // Destruimos la variable
                unset($MySQLi);
                if ($cerrar) {
                    $response = '<hr>Conexion a la Base de Datos Cerrada !!!';
                }
                else{
                    $response = '<hr>La Conexion a la Base de Datos sigue Abierta !!!';
                }
            }
            else{
                $response = '<hr>Conexion no esta definida';
            }
            // echo $response;
		}


		// Metodo para hacer Querys
		public function queryFunction($sql){
			$MySQLi = $this->mysqli;
			// Quitamos espacios de inicio y final
			$sql = trim($sql);

			try {
			// Guardamos en $result_set el resultado de la query
			$result_set = $MySQLi->query($sql);
			} catch (Exception $e) {
				if ($errno == 1062) {
					echo"<script language='JavaScript'>
                            alert('Clave Única repetida, contacte al desarrollador del sistema !!!');
                            window.history.back();
                        </script>";
				}
				$error ='<br>
						<div class="centrar" style="font-size:25px;">
							<div class="label label-danger">
            					Error en la Query, contacte con un Administrador !!!
        					</div>
        				</div>
        				<br>';
        		echo $error;

				$error = ($MySQLi->error);
				$errno = ($MySQLi->errno);
				$debugger = '';
				$debugger .= '<br>Error en consulta :<pre> ' . $sql .'</pre>';
				$debugger .= 'Error: <b>'.$errno.'</b>, Detalle: <b>'.$error.'</b><br>';
				$debugger .= '<br>
								<center>
								<div class="centrar" style="font-size:25px;background-color:#E94816;">
									<div class="label label-danger">
		            					<b>Desabilitar Debbugger !!!</b>
		        					</div>
		        				</div>
		        				</center>
		        			<br>';
				// Para ver error
				// echo $debugger;
			}
			$lastID = $MySQLi->insert_id;


			// return $result_set;
			return array($result_set,$lastID);
		}

		// Metodo para los arrays de las querys
		public function fetchAssocFunction($statement){
			if ($statement[0]) {
				return $statement[0]->fetch_assoc();
			}
		}

		// Metodo para ver el numero de rows devueltas
		public function numRowsFunction($statement){
			return $statement[0]->num_rows;
		}

		// Metodo para los While de las querys
		public function whileFunction($loop){
			$results = array();
			while ($result = $this->fetchAssocFunction($loop)){
				$results[] = $result;
			}
			return $results;
		}

		// Metodo para los contadores
		public function counter(){
			static $count = 1;
			return $count ++;
		}

		// Metodo para "Escapar" caracteres
		public function realEscapeStringFunction($str){
			$MySQLi = $this->mysqli;

			return $MySQLi->real_escape_string($str);
		}

	}
	$dbm = new DBM();
	$dbm->conexion();
?>