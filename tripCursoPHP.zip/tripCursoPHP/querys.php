<?php

	require_once('database.php');

    class Querys{
        public function __construct(){
            $this->dbm = new DBM();
            $this->dbm->conexion();
            return $this->dbm->conexion();
        }
        public function getTrip(){
            $sql = "SELECT gasto, monto FROM trip WHERE trip = 'IT-2024' ";
            $result = $this->dbm->queryFunction($sql);
            $trip = $this->dbm->whileFunction($result);
            if ($this->dbm->numRowsFunction($result) > 0) {
                return $trip;
            }
        }

        public function getTotal(){
            $sql = "SELECT SUM(monto) AS total FROM trip WHERE trip = 'IT-2024' ";
            $result = $this->dbm->queryFunction($sql);
            $trip = $this->dbm->whileFunction($result);
            if ($this->dbm->numRowsFunction($result) > 0) {
                return $trip;
            }
        }

        public function insertGasto($gasto, $monto){
            $sql = "INSERT INTO trip VALUES ('','IT-2024','$gasto',$monto) ";
            $result = $this->dbm->queryFunction($sql);
            return $result;
        }
    }
    $querys = new Querys();
?>