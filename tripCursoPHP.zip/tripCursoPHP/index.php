<?php
	require_once('querys.php');

	$trip = $querys->getTrip();
	$total = $querys->getTotal()[0]['total'];

	if ($_POST) {
		$gasto = $_POST['gasto'];
		$monto = $_POST['monto'];

		$gasto = $querys->insertGasto($gasto, $monto);

		$trip = $querys->getTrip();
		$total = $querys->getTotal()[0]['total'];
	}

?>
<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel=icon href='https://tiendaeconomica.es/wp-content/uploads/2023/10/logo.png' sizes="32x32" type="image/png">
	<title>OCHOA Trips</title>
	<!-- BootStrap -->
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-BmbxuPwQa2lc/FVzBcNJ7UAyJxM6wuqIj61tLrc4wSX0szH/Ev+nYRRuWlolflfl" crossorigin="anonymous">
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/js/bootstrap.bundle.min.js" integrity="sha384-b5kHyXgcpbZJO/tY9Ul7kGkf1S0CWuKcCD38l8YkeH8z8QjE0GmW1gYU5S9FOnJ0" crossorigin="anonymous"></script>
	<!-- OCHOA CSS Style -->
	<link rel="stylesheet" href="OCHOA.css" type="text/css">
	<!-- FontAwesome -->
	<link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>
</head>
<body>
	<div class="navbar headerBG justify-content-center">
      	<h1>Italy Trip</h1>
	</div>
	<br>
	<?php
		switch (true) {
			case $total > 400:
				$alert = 'danger';
				break;

			case $total > 250:
				$alert = 'warning';
				break;

			default:
				$alert = 'success';
				break;
		}
	?>
	<div class="container text-center">
		<div class="alert alert-<?php echo $alert; ?>" role="alert">
		  Costo total del Viaje
		  <div class="total">
		  	<?php echo $total.'€'; ?>
		  </div>
		</div>
	</div>
	<div class="container">
		<form action="" method="POST">
			<div class="container">
				<input type="text" id="gasto" name="gasto" placeholder="Concepto del Gasto" required autofocus>
				<input type="decimal" id="monto" name="monto" placeholder="Monto" required>
			</div>
			<br>
			<div class="container">
				<input type="submit" class="btn btn-primary" value="Guardar">
			</div>
		</form>
	</div>
	<br>
	<div class="container">
		<div class="container table-responsive">
			<table class="table table-bordered table-hover">
				<thead>
					<tr class="table-primary">
						<th scope="col" class="text-center">GASTO</th>
						<th scope="col" class="text-center">MONTO</th>
					</tr>
				</thead>
				<?php
					if($trip){
						foreach ($trip as $gasto) {
				?>
				<tbody>
					<tr>
						<td>
							<?php echo $gasto['gasto']; ?>
						</td>
						<td>
							<?php echo $gasto['monto'].'€'; ?>
						</td>
					</tr>
				</tbody>
				<?php
						}
					}
				?>
			</table>
		</div>
	</div>
</body>
</html>